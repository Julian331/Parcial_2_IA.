"""Punto 1. Algoritmo genético para maximizar f(x) = x^2, x en {0, ..., 31}.

Cada solución es un cromosoma binario de 5 bits (texto como "01100").
Ejecutar:  python punto1_genetico.py
"""
import os
import random

import matplotlib
matplotlib.use("Agg")  # guarda la figura en archivo sin abrir ventanas
import matplotlib.pyplot as plt

# Parámetros del enunciado
POBLACION_INICIAL = ["00101", "01100", "10010", "11001"]
PROB_CRUCE = 0.8
PROB_MUTACION = 0.05
GENERACIONES = 20
SEMILLA = 42
N_BITS = 5


def decodificar(cromosoma):
    """Binario -> decimal. Ej.: "01100" -> 12."""
    return int(cromosoma, 2)


def aptitud(cromosoma):
    """f(x) = x^2."""
    x = decodificar(cromosoma)
    return x ** 2


def probabilidades_ruleta(poblacion):
    """p_i = f(x_i) / suma de f(x_j)."""
    total = sum(aptitud(c) for c in poblacion)
    return [aptitud(c) / total for c in poblacion]


def seleccion_ruleta(poblacion):
    """Gira la ruleta una vez: r en [0, 1) y se elige el intervalo acumulado que contiene a r."""
    probs = probabilidades_ruleta(poblacion)
    r = random.random()
    acumulado = 0.0
    for cromosoma, p in zip(poblacion, probs):
        acumulado += p
        if r < acumulado:
            return cromosoma
    return poblacion[-1]  # solo por redondeo, si r queda en el borde final


def cruce_un_punto(padre1, padre2, punto):
    """Corta después del bit 'punto' e intercambia las colas."""
    hijo1 = padre1[:punto] + padre2[punto:]
    hijo2 = padre2[:punto] + padre1[punto:]
    return hijo1, hijo2


def invertir_bit(cromosoma, posicion):
    """Cambia 0 por 1 o 1 por 0 en la posición dada (0 = primer bit)."""
    bit = "1" if cromosoma[posicion] == "0" else "0"
    return cromosoma[:posicion] + bit + cromosoma[posicion + 1:]


def mutar(cromosoma):
    """Mutación independiente por bit con probabilidad PROB_MUTACION."""
    for i in range(N_BITS):
        if random.random() < PROB_MUTACION:
            cromosoma = invertir_bit(cromosoma, i)
    return cromosoma


def nueva_generacion(poblacion):
    """Genera 4 hijos (2 parejas) y reemplaza al peor hijo por el élite."""
    elite = max(poblacion, key=aptitud)
    hijos = []
    for _ in range(len(poblacion) // 2):
        padre1 = seleccion_ruleta(poblacion)
        padre2 = seleccion_ruleta(poblacion)
        if random.random() < PROB_CRUCE:
            punto = random.randint(1, N_BITS - 1)  # corte entre 1 y 4
            hijo1, hijo2 = cruce_un_punto(padre1, padre2, punto)
        else:
            hijo1, hijo2 = padre1, padre2  # sin cruce: copias de los padres
        hijos.append(mutar(hijo1))
        hijos.append(mutar(hijo2))
    # Elitismo: el élite (sin mutar) ocupa el lugar del peor hijo
    peor = min(range(len(hijos)), key=lambda i: aptitud(hijos[i]))
    hijos[peor] = elite
    return hijos


def algoritmo_genetico():
    random.seed(SEMILLA)
    poblacion = list(POBLACION_INICIAL)
    historial = [max(aptitud(c) for c in poblacion)]  # generación 0
    poblaciones = [poblacion]
    for _ in range(GENERACIONES):
        poblacion = nueva_generacion(poblacion)
        poblaciones.append(poblacion)
        historial.append(max(aptitud(c) for c in poblacion))
    mejor = max(poblacion, key=aptitud)
    return mejor, historial, poblaciones


def verificar_parte_a():
    """Comprueba con el código los cálculos hechos a mano en la parte A."""
    assert [decodificar(c) for c in POBLACION_INICIAL] == [5, 12, 18, 25]
    assert [aptitud(c) for c in POBLACION_INICIAL] == [25, 144, 324, 625]
    probs = probabilidades_ruleta(POBLACION_INICIAL)
    esperadas = [25 / 1118, 144 / 1118, 324 / 1118, 625 / 1118]
    assert all(abs(p - e) < 1e-12 for p, e in zip(probs, esperadas))
    assert abs(sum(probs) - 1) < 1e-12
    hijos = cruce_un_punto("01100", "11001", 2)
    assert hijos == ("01001", "11100")
    mutado = invertir_bit(hijos[0], N_BITS - 1)
    assert mutado == "01000" and decodificar(mutado) == 8 and aptitud(mutado) == 64
    print("Parte A verificada:")
    for c, p in zip(POBLACION_INICIAL, probs):
        print(f"  {c}  x = {decodificar(c):2d}  f = {aptitud(c):3d}  p = {p:.4f}")
    print(f"  Cruce 01|100 x 11|001 -> {hijos}; mutación -> {mutado} (x = 8, f = 64)\n")


if __name__ == "__main__":
    verificar_parte_a()
    mejor, historial, poblaciones = algoritmo_genetico()

    print("Gen | Mejor f | Población")
    for g, (f, pob) in enumerate(zip(historial, poblaciones)):
        print(f"{g:3d} | {f:7d} | {' '.join(pob)}")
    print(f"\nMejor cromosoma final: {mejor}  x = {decodificar(mejor)}  f = {aptitud(mejor)}")
    print("Máximo posible: 11111  x = 31  f = 961")

    os.makedirs("resultados", exist_ok=True)
    with open("resultados/punto1_historial.csv", "w") as archivo:
        archivo.write("generacion,mejor_aptitud,poblacion\n")
        for g, (f, pob) in enumerate(zip(historial, poblaciones)):
            archivo.write(f"{g},{f},{' '.join(pob)}\n")

    plt.figure(figsize=(6, 3.5))
    plt.plot(range(len(historial)), historial, marker="o", color="black")
    plt.axhline(961, linestyle="--", color="gray", label="Máximo global (961)")
    plt.xlabel("Generación")
    plt.ylabel("Mejor aptitud f(x)")
    plt.xticks(range(0, GENERACIONES + 1, 2))
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig("resultados/punto1_historial.pdf")
