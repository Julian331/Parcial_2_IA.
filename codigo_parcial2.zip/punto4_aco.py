"""Punto 4. ACO: regla de transición, actualización de feromonas y modelo simplificado de rutas.

Parte B: tres rutas completas de A a Z, una feromona por ruta.
Ejecutar:  python punto4_aco.py
"""
import os
import random

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Parámetros del enunciado
ALFA = 1
BETA = 2
RHO = 0.2
Q = 10
HORMIGAS = 10
ITERACIONES = 20
SEMILLA = 42

RUTAS = ["A-B-Z", "A-C-Z", "A-D-Z"]
LONGITUDES = [6, 8, 10]


def pesos(feromonas, distancias):
    """Peso de cada alternativa: tau^alfa * (1/d)^beta (con eta = 1/d)."""
    return [(tau ** ALFA) * ((1 / d) ** BETA) for tau, d in zip(feromonas, distancias)]


def probabilidades(feromonas, distancias):
    """p_j = peso_j / suma de pesos."""
    w = pesos(feromonas, distancias)
    total = sum(w)
    return [x / total for x in w]


def ruleta(probs):
    """r en [0, 1) y se elige el intervalo acumulado que contiene a r (08 pág. 17)."""
    r = random.random()
    acumulado = 0.0
    for indice, p in enumerate(probs):
        acumulado += p
        if r < acumulado:
            return indice
    return len(probs) - 1  # solo por redondeo


def evaporar(feromonas):
    """tau <- (1 - rho) * tau en todas las rutas."""
    return [(1 - RHO) * tau for tau in feromonas]


def aco_rutas():
    random.seed(SEMILLA)
    feromonas = [1.0, 1.0, 1.0]
    hist_feromonas = [list(feromonas)]  # iteración 0
    hist_probs = []
    hist_conteos = []
    for _ in range(ITERACIONES):
        probs = probabilidades(feromonas, LONGITUDES)  # 1. probabilidades con tau actual
        elecciones = [ruleta(probs) for _ in range(HORMIGAS)]  # 2. las 10 hormigas eligen
        feromonas = evaporar(feromonas)  # 3. evaporación
        for r in elecciones:  # 4. cada hormiga deposita Q / L en su ruta
            feromonas[r] += Q / LONGITUDES[r]
        hist_probs.append(probs)
        hist_conteos.append([elecciones.count(r) for r in range(len(RUTAS))])
        hist_feromonas.append(list(feromonas))
    return hist_probs, hist_conteos, hist_feromonas


def verificar_parte_a():
    """Comprueba los cálculos manuales de la parte A (nodo A con destinos B, C, D)."""
    distancias = [2, 4, 5]
    tau = [1, 2, 1]
    w = pesos(tau, distancias)
    p = probabilidades(tau, distancias)
    assert [round(x, 4) for x in w] == [0.25, 0.125, 0.04]
    assert abs(sum(w) - 0.415) < 1e-12
    assert [round(x, 4) for x in p] == [0.6024, 0.3012, 0.0964]
    # Actualización con rho = 0.2, Q = 10, L = 10; solo A->B recibe depósito
    deposito = [Q / 10, 0, 0]
    nueva = [t + dt for t, dt in zip(evaporar(tau), deposito)]
    assert [round(x, 10) for x in nueva] == [1.8, 1.6, 0.8]
    print("Parte A verificada:")
    for destino, wi, pi in zip("BCD", w, p):
        print(f"  A->{destino}: peso = {wi:.4f}, p = {pi:.4f}")
    print(f"  Suma de pesos = {sum(w):.3f}; feromonas nuevas (B, C, D) = {nueva}\n")


if __name__ == "__main__":
    verificar_parte_a()
    hist_probs, hist_conteos, hist_feromonas = aco_rutas()

    print("Iter | p(ABZ)  p(ACZ)  p(ADZ) | elecciones ABZ ACZ ADZ | tau ABZ   tau ACZ  tau ADZ")
    for k in range(ITERACIONES):
        p, c, t = hist_probs[k], hist_conteos[k], hist_feromonas[k + 1]
        print(f"{k + 1:4d} | {p[0]:.4f}  {p[1]:.4f}  {p[2]:.4f} |"
              f"            {c[0]:3d} {c[1]:3d} {c[2]:3d} | {t[0]:8.4f} {t[1]:8.4f} {t[2]:8.4f}")

    totales = [sum(c[r] for c in hist_conteos) for r in range(len(RUTAS))]
    total_elecciones = HORMIGAS * ITERACIONES
    print("\nFrecuencias totales de elección:")
    for ruta, n in zip(RUTAS, totales):
        print(f"  {ruta}: {n} de {total_elecciones} ({n / total_elecciones:.1%})")
    print("Feromonas finales:", [round(t, 4) for t in hist_feromonas[-1]])
    elegidas = [r for r in range(len(RUTAS)) if totales[r] > 0]
    mas_corta = min(elegidas, key=lambda r: LONGITUDES[r])
    mas_elegida = max(range(len(RUTAS)), key=lambda r: totales[r])
    print(f"Mejor ruta observada (la más corta elegida): {RUTAS[mas_corta]} (L = {LONGITUDES[mas_corta]})")
    print(f"Ruta más elegida: {RUTAS[mas_elegida]} ({totales[mas_elegida]} veces)")

    os.makedirs("resultados", exist_ok=True)
    with open("resultados/punto4_historial.csv", "w") as archivo:
        archivo.write("iteracion,p_ABZ,p_ACZ,p_ADZ,n_ABZ,n_ACZ,n_ADZ,tau_ABZ,tau_ACZ,tau_ADZ\n")
        for k in range(ITERACIONES):
            fila = hist_probs[k] + hist_conteos[k] + hist_feromonas[k + 1]
            archivo.write(f"{k + 1}," + ",".join(str(round(v, 6)) for v in fila) + "\n")

    estilos = ["-", "--", ":"]
    fig, (eje_tau, eje_p) = plt.subplots(2, 1, figsize=(6, 5), sharex=True)
    for r in range(len(RUTAS)):
        eje_tau.plot(range(ITERACIONES + 1), [t[r] for t in hist_feromonas],
                     color="black", linestyle=estilos[r], label=f"{RUTAS[r]} (L = {LONGITUDES[r]})")
        eje_p.plot(range(1, ITERACIONES + 1), [p[r] for p in hist_probs],
                   color="black", linestyle=estilos[r])
    eje_tau.set_ylabel("Feromona τ")
    eje_tau.legend(frameon=False)
    eje_p.set_ylabel("Probabilidad de elección")
    eje_p.set_xlabel("Iteración")
    eje_p.set_xticks(range(0, ITERACIONES + 1, 2))
    fig.tight_layout()
    fig.savefig("resultados/punto4_historial.pdf")
