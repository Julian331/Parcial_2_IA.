Parcial 2 - Inteligencia Artificial
Universidad Sergio Arboleda - Docente: Joaquín Fernando Sánchez Cifuentes
Integrantes: Gabriela Delgado Tibamoso, Julian Camilo Caro Herrera, Nicolás Steven Pérez Chuscano

Requisitos: Python 3, matplotlib y numpy
    pip install matplotlib numpy

Ejecución (cada punto es independiente):
    python punto1_genetico.py          Algoritmo genético (f(x) = x^2, 5 bits)
    python punto2_ascenso_colinas.py   Ascenso de colinas desde los 9 estados
    python punto3_temple_simulado.py   Temple simulado (E(x) = x^2)
    python punto4_aco.py               ACO simplificado con 3 rutas
    python punto5_pso.py               PSO para f(x, y) = x^2 + y^2

Cada archivo:
  1. verifica con assert los cálculos manuales de la parte A;
  2. ejecuta la parte B con semilla 42 y muestra los resultados en consola;
  3. guarda en la carpeta resultados/ la gráfica (.pdf) y el historial (.csv).

Generadores: módulo random de Python en los puntos 1, 3 y 4;
numpy.random.default_rng(42) en el punto 5; el punto 2 es determinista.
