"""Punto 5. PSO: movimiento de partículas y memoria.

Parte A: una actualización a mano (x = 4, v = -1, pbest = 2, gbest = 1).
Parte B: PSO para minimizar f(x, y) = x^2 + y^2 en [-5, 5]^2.
Ejecutar:  python punto5_pso.py
"""
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# Parte A: cálculo manual verificado
def parte_a():
    x, v, pbest, gbest = 4, -1, 2, 1
    w, c1, c2, r1, r2 = 0.5, 1.5, 1.5, 0.4, 0.6
    inercia = w * v
    cognitivo = c1 * r1 * (pbest - x)
    social = c2 * r2 * (gbest - x)
    v_new = inercia + cognitivo + social
    x_new = x + v_new
    print("Inercia   :", inercia)
    print("Cognitivo :", cognitivo)
    print("Social    :", social)
    print("v_nueva   :", v_new)
    print("x_nueva   :", x_new, " f =", x_new**2)
    print("f(pbest)=", pbest**2, " f(gbest)=", gbest**2)
    # Comprobación de los valores calculados a mano (el redondeo evita el ruido de punto flotante)
    assert round(inercia, 10) == -0.5 and round(cognitivo, 10) == -1.2 and round(social, 10) == -2.7
    assert round(v_new, 10) == -4.4 and round(x_new, 10) == -0.4 and round(x_new**2, 10) == 0.16
    assert x_new**2 < pbest**2 and x_new**2 < gbest**2  # mejora pbest y gbest


# Parte B: PSO en 2D
def f(p):
    return np.sum(p**2, axis=-1)


def pso(n=10, iters=30, w=0.5, c1=1.5, c2=1.5, lo=-5.0, hi=5.0, seed=42):
    rng = np.random.default_rng(seed)
    pos = rng.uniform(lo, hi, size=(n, 2))
    vel = np.zeros((n, 2))
    fit = f(pos)
    pbest_pos, pbest_fit = pos.copy(), fit.copy()
    i = np.argmin(pbest_fit)
    gbest_pos, gbest_fit = pbest_pos[i].copy(), pbest_fit[i]
    historial = [gbest_fit]            # iteración 0 (estado inicial)

    for _ in range(iters):
        r1 = rng.random((n, 2))        # independientes por partícula y dimensión
        r2 = rng.random((n, 2))
        # mismo gbest para todas las partículas en esta iteración
        vel = w*vel + c1*r1*(pbest_pos - pos) + c2*r2*(gbest_pos - pos)
        pos = pos + vel
        # límites: ajustar al borde y anular la componente de velocidad
        bajo, alto = pos < lo, pos > hi
        pos = np.clip(pos, lo, hi)
        vel[bajo | alto] = 0.0
        # evaluar y actualizar memorias (después de mover todas)
        fit = f(pos)
        mejora = fit < pbest_fit
        pbest_pos[mejora] = pos[mejora]
        pbest_fit[mejora] = fit[mejora]
        i = np.argmin(pbest_fit)
        if pbest_fit[i] < gbest_fit:
            gbest_fit, gbest_pos = pbest_fit[i], pbest_pos[i].copy()
        historial.append(gbest_fit)
    return gbest_pos, gbest_fit, historial


if __name__ == "__main__":
    parte_a()
    print()
    pos, fit, hist = pso()
    print("Mejor posición final:", pos)
    print("f(mejor)            :", fit)
    print("Historial mejor aptitud global (iter 0..30):")
    for k, h in enumerate(hist):
        print(f"  {k:2d}: {h:.10f}")

    # Tabla y gráfica del historial (mismo formato que los puntos 1-4)
    os.makedirs("resultados", exist_ok=True)
    with open("resultados/punto5_historial.csv", "w") as archivo:
        archivo.write("iteracion,mejor_aptitud_global\n")
        for k, h in enumerate(hist):
            archivo.write(f"{k},{h:.10e}\n")

    plt.figure(figsize=(6, 3.5))
    plt.semilogy(range(len(hist)), hist, marker="o", color="black")
    plt.xlabel("Iteración")
    plt.ylabel("Mejor aptitud global f(gbest)")
    plt.xticks(range(0, len(hist), 2))
    plt.tight_layout()
    plt.savefig("resultados/punto5_historial.pdf")
