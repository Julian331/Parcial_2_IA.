"""Punto 2. Ascenso de colinas (variante de ascenso más pronunciado) sobre un espacio discreto.

Maximizar f(x) con x en {0, ..., 8}. Vecinos de x: x - 1 y x + 1 si están en el dominio.
Se elige el vecino con mayor valor y solo se mueve si hay mejora estricta.
Ejecutar:  python punto2_ascenso_colinas.py
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

VALORES = [1, 4, 7, 5, 3, 6, 9, 8, 5]  # f(0), f(1), ..., f(8)


def vecinos(x, n):
    """Devuelve los vecinos válidos de x en el dominio {0, ..., n - 1}."""
    resultado = []
    if x - 1 >= 0:
        resultado.append(x - 1)
    if x + 1 <= n - 1:
        resultado.append(x + 1)
    return resultado


def ascenso_colinas(valores, inicio):
    """Devuelve el estado final y la trayectoria."""
    actual = inicio
    trayectoria = [actual]
    while True:
        mejor_vecino = max(vecinos(actual, len(valores)), key=lambda v: valores[v])
        if valores[mejor_vecino] <= valores[actual]:  # sin mejora estricta: se detiene
            return actual, trayectoria
        actual = mejor_vecino
        trayectoria.append(actual)


def maximos_locales(valores):
    """Estados cuyo valor es mayor o igual que el de todos sus vecinos."""
    n = len(valores)
    return [x for x in range(n) if all(valores[x] >= valores[v] for v in vecinos(x, n))]


def verificar_parte_a():
    """Comprueba con el código las ejecuciones manuales de la parte A."""
    assert ascenso_colinas(VALORES, 0) == (2, [0, 1, 2])
    assert ascenso_colinas(VALORES, 4) == (6, [4, 5, 6])
    assert maximos_locales(VALORES) == [2, 6]
    assert VALORES.index(max(VALORES)) == 6
    print("Parte A verificada: desde 0 -> [0, 1, 2]; desde 4 -> [4, 5, 6]; "
          "máximos locales {2, 6}; máximo global x = 6 (f = 9)\n")


if __name__ == "__main__":
    verificar_parte_a()
    global_x = VALORES.index(max(VALORES))

    filas = []
    for inicio in range(len(VALORES)):
        final, trayectoria = ascenso_colinas(VALORES, inicio)
        filas.append((inicio, trayectoria, final, VALORES[final]))

    print("Inicio | Trayectoria   | Final | f(final)")
    for inicio, trayectoria, final, valor in filas:
        texto = " -> ".join(str(x) for x in trayectoria)
        print(f"{inicio:6d} | {texto:13s} | {final:5d} | {valor:8d}")
    exitos = sum(1 for fila in filas if fila[2] == global_x)
    print(f"\nLlegan al máximo global (x = {global_x}): {exitos} de {len(VALORES)} "
          f"= {exitos / len(VALORES):.3f}")

    os.makedirs("resultados", exist_ok=True)
    with open("resultados/punto2_tabla.csv", "w") as archivo:
        archivo.write("inicio,trayectoria,final,valor_final\n")
        for inicio, trayectoria, final, valor in filas:
            archivo.write(f"{inicio},{' -> '.join(map(str, trayectoria))},{final},{valor}\n")

    # Figura: paisaje f(x); los estados que terminan en el máximo global van en negro.
    plt.figure(figsize=(6, 3.5))
    plt.plot(range(len(VALORES)), VALORES, color="gray", linestyle="--")
    for inicio, _, final, _ in filas:
        relleno = "black" if final == global_x else "white"
        plt.scatter(inicio, VALORES[inicio], s=60, color=relleno, edgecolor="black", zorder=3)
    plt.scatter([], [], color="black", edgecolor="black", label="Termina en el máximo global (x = 6)")
    plt.scatter([], [], color="white", edgecolor="black", label="Termina en el máximo local (x = 2)")
    plt.xlabel("Estado x")
    plt.ylabel("f(x)")
    plt.xticks(range(len(VALORES)))
    plt.legend(frameon=False, loc="upper left")
    plt.tight_layout()
    plt.savefig("resultados/punto2_paisaje.pdf")
