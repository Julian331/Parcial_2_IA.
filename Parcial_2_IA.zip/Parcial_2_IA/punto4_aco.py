import random

# ---------- Parámetros ----------
rutas = {"A-B-Z": 6, "A-C-Z": 8, "A-D-Z": 10}   # longitud total de cada ruta
alpha, beta = 1, 2
rho, Q = 0.2, 10
n_hormigas, n_iter = 10, 20
random.seed(42)

tau = {r: 1.0 for r in rutas}                    # feromona inicial = 1
frecuencias = {r: 0 for r in rutas}
mejor_ruta, mejor_long = None, float("inf")

def probabilidades(tau):
    pesos = {r: (tau[r] ** alpha) * ((1 / L) ** beta) for r, L in rutas.items()}
    total = sum(pesos.values())
    return {r: p / total for r, p in pesos.items()}

for it in range(1, n_iter + 1):
    # 1. Probabilidades con las feromonas actuales
    probs = probabilidades(tau)

    # 2. Las 10 hormigas eligen con esas mismas probabilidades
    elegidas = random.choices(list(rutas), weights=list(probs.values()), k=n_hormigas)
    for r in elegidas:
        frecuencias[r] += 1
        if rutas[r] < mejor_long:
            mejor_ruta, mejor_long = r, rutas[r]

    # 3. Evaporación en todas las rutas
    for r in tau:
        tau[r] *= (1 - rho)

    # 4. Cada hormiga deposita Q/L en su ruta
    for r in elegidas:
        tau[r] += Q / rutas[r]

    print(f"Iter {it:2d} | p = " +
          ", ".join(f"{r}:{p:.3f}" for r, p in probs.items()) +
          " | elegidas: " + ", ".join(f"{r}={elegidas.count(r)}" for r in rutas))

print("\nFrecuencias de elección:", frecuencias, "(total", sum(frecuencias.values()), ")")
print("Feromonas finales:", {r: round(t, 4) for r, t in tau.items()})
print("Mejor ruta observada:", mejor_ruta, "con longitud", mejor_long)
