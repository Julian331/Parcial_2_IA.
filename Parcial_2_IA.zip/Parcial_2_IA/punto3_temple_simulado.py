"""Punto 3. Temple simulado para minimizar E(x) = x^2, x en {-5, ..., 5}.

Regla de aceptación: si dE <= 0 se acepta; si dE > 0 se acepta cuando u < exp(-dE / T).
Ejecutar:  python punto3_temple_simulado.py
"""
import math
import os
import random

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Parámetros del enunciado
X_MIN, X_MAX = -5, 5
X0 = 5
T0 = 10
ALFA = 0.90  # T(k+1) = 0.90 * T(k)
ITERACIONES = 100
SEMILLA = 42


def energia(x):
    """E(x) = x^2 (se minimiza)."""
    return x ** 2


def probabilidad_aceptar(delta_e, temperatura):
    """1 si la solución no empeora; e^(-dE/T) si empeora."""
    if delta_e <= 0:
        return 1.0
    return math.exp(-delta_e / temperatura)


def vecinos(x):
    """Vecinos válidos de x: x - 1 y x + 1 dentro de [-5, 5]."""
    return [v for v in (x - 1, x + 1) if X_MIN <= v <= X_MAX]


def temple_simulado():
    random.seed(SEMILLA)
    actual = X0
    mejor = X0
    temperatura = T0
    historial = [(0, temperatura, actual, energia(actual), mejor, energia(mejor))]
    for k in range(1, ITERACIONES + 1):
        candidato = random.choice(vecinos(actual))
        delta_e = energia(candidato) - energia(actual)
        # u solo se genera si el candidato es peor (igual que 06 pág. 18)
        if delta_e <= 0 or random.random() < probabilidad_aceptar(delta_e, temperatura):
            actual = candidato
            if energia(actual) < energia(mejor):
                mejor = actual
        historial.append((k, temperatura, actual, energia(actual), mejor, energia(mejor)))
        temperatura = ALFA * temperatura  # enfriamiento geométrico, una vez por iteración
    return mejor, historial


def verificar_parte_a():
    """Comprueba los tres casos calculados a mano en la parte A."""
    casos = [("A", 3, 2, 5, 0.70), ("B", 2, 3, 5, 0.30), ("C", 2, 3, 1, 0.30)]
    print("Parte A verificada:")
    for nombre, x_act, x_cand, t, u in casos:
        delta_e = energia(x_cand) - energia(x_act)
        p = probabilidad_aceptar(delta_e, t)
        acepta = delta_e <= 0 or u < p
        print(f"  Caso {nombre}: dE = {delta_e:+d}, P = {p:.4f}, u = {u:.2f} -> "
              f"{'acepta' if acepta else 'rechaza'}")
    assert probabilidad_aceptar(-5, 5) == 1.0
    assert abs(probabilidad_aceptar(5, 5) - math.exp(-1)) < 1e-12   # 0.3679 > 0.30 -> acepta
    assert abs(probabilidad_aceptar(5, 1) - math.exp(-5)) < 1e-12   # 0.0067 < 0.30 -> rechaza
    print()


if __name__ == "__main__":
    verificar_parte_a()
    mejor, historial = temple_simulado()

    print("  k |       T | x actual | E actual | mejor x | E mejor")
    for k, t, x, e, mx, me in historial:
        print(f"{k:3d} | {t:7.4f} | {x:8d} | {e:8d} | {mx:7d} | {me:7d}")
    print(f"\nMejor solución: x = {mejor}, energía mínima E = {energia(mejor)}")
    primera = next(k for k, _, _, _, mx, _ in historial if energia(mx) == energia(mejor))
    print(f"Se alcanzó por primera vez en la iteración {primera}")

    os.makedirs("resultados", exist_ok=True)
    with open("resultados/punto3_historial.csv", "w") as archivo:
        archivo.write("iteracion,temperatura,x_actual,E_actual,mejor_x,E_mejor\n")
        for fila in historial:
            archivo.write(",".join(str(round(v, 6)) for v in fila) + "\n")

    ks = [fila[0] for fila in historial]
    fig, (eje_t, eje_e) = plt.subplots(2, 1, figsize=(6, 5), sharex=True)
    eje_t.plot(ks, [fila[1] for fila in historial], color="black")
    eje_t.set_ylabel("Temperatura T")
    eje_e.step(ks, [fila[3] for fila in historial], where="post", color="gray", label="E actual")
    eje_e.step(ks, [fila[5] for fila in historial], where="post", color="black",
               linestyle="--", label="E de la mejor solución")
    eje_e.set_xlabel("Iteración k")
    eje_e.set_ylabel("Energía E(x)")
    eje_e.legend(frameon=False)
    fig.tight_layout()
    fig.savefig("resultados/punto3_historial.pdf")
